/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2018, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "./custom.h"
#include <cmath>

#define M_PI 3.14159265358979323846  /* pi */

// declare cell definitions here 

Cell_Definition motile_cell; 
Cell_Definition bob_cell;
Cell_Definition TA_cell;
Cell_Definition fred_cell;

// initialising random variables
double r1;
double r2;

// Which simulation to run?
bool secretion_test = false;		// spiral bob cells and random motile cells
bool secretion_test2 = false;		// vertical line bob cells and random motile cells
bool secretion_test3 = false;		// random bob cells in the middle and motile cells in a big circle
bool differentiation_test = false;	// random motile cells and random bob cells in the middle
bool chemotaxis_center = false;		// motile cells in a circle
bool null_model = false;			// random motile cells in the middle
bool spiral = false;				// motile cells in a big circle and bob cells in a spiral
bool spiral2 = false;				// random motile cells on the left and bob cells in a spiral
bool spiral3 = false;				// multiple bob cell spirals with smaller curve
bool spiral4 = true;				// 8 way bob cell spiral and motile cells in a circle and fred cells in a random circle same size
bool adhesion = false;				// one motile cell and one adjacent bob cell
bool grid = false;					// bob cells in a grid and motile cells optional
bool proliferation_test = false;	// random motile cells and random bob cells on the right side
bool topography = false;			// small circle of bob cells and random motile cells inside the circle

// Which custom functions do we want?
bool chemotaxis = true;			// motile cells chemotaxis up glucose gradient
bool dirichlet_center = false;		// set dirichlet conditions for glucose gradient higher in the middle
bool proliferation = false;			// motile cells proliferate faster on contact with bob cells
bool differentiation = true;		// TA cells created when motile cells touch bob cells
bool secretion = true;				// bob cells secrete chemoattractant

void create_cell_types( void )
{
	// use the same random seed so that future experiments have the 
	// same initial histogram of oncoprotein, even if threading means 
	// that future division and other events are still not identical 
	// for all runs 
	
	SeedRandom( parameters.ints("random_seed") ); // or specify a seed here 
	
	// housekeeping 
	
	initialize_default_cell_definition();
	cell_defaults.phenotype.secretion.sync_to_microenvironment( &microenvironment ); 
	
	// Name the default cell type 
	
	cell_defaults.type = 0; 
	cell_defaults.name = "tumor cell"; 
	
	// set default cell cycle model 

	cell_defaults.functions.cycle_model = flow_cytometry_separated_cycle_model; 
	
	// set default_cell_functions; 
	
	cell_defaults.functions.update_phenotype = update_cell_and_death_parameters_O2_based; 
	
	// needed for a 2-D simulation: 
	
	/* grab code from heterogeneity */ 
	
	cell_defaults.functions.set_orientation = up_orientation; 
	cell_defaults.phenotype.geometry.polarity = 1.0;
	cell_defaults.phenotype.motility.restrict_to_2D = true; 
	
	// make sure the defaults are self-consistent. 
	
	cell_defaults.phenotype.secretion.sync_to_microenvironment( &microenvironment );
	cell_defaults.phenotype.molecular.sync_to_microenvironment( &microenvironment );	
	cell_defaults.phenotype.sync_to_functions( cell_defaults.functions ); 

	// set the rate terms in the default phenotype 

	// first find index for a few key variables. 
	int apoptosis_model_index = cell_defaults.phenotype.death.find_death_model_index( "Apoptosis" );
	int necrosis_model_index = cell_defaults.phenotype.death.find_death_model_index( "Necrosis" );
	int oxygen_substrate_index = microenvironment.find_density_index( "oxygen" ); 

	int G0G1_index = flow_cytometry_separated_cycle_model.find_phase_index( PhysiCell_constants::G0G1_phase );
	int S_index = flow_cytometry_separated_cycle_model.find_phase_index( PhysiCell_constants::S_phase );

	// initially no necrosis 
	cell_defaults.phenotype.death.rates[necrosis_model_index] = 0.0; 

	// set oxygen uptake / secretion parameters for the default cell type 
	cell_defaults.phenotype.secretion.uptake_rates[oxygen_substrate_index] = 10; 
	cell_defaults.phenotype.secretion.secretion_rates[oxygen_substrate_index] = 0; 
	cell_defaults.phenotype.secretion.saturation_densities[oxygen_substrate_index] = 38; 
	
	// add custom data here, if any 

	/* for the tutorial */
	cell_defaults.phenotype.cycle.data.transition_rate(G0G1_index, S_index) =
		parameters.doubles("base_cycle_entry_rate");
	cell_defaults.phenotype.death.rates[apoptosis_model_index] =
		parameters.doubles("base_apoptosis_rate");

	cell_defaults.phenotype.mechanics.set_relative_maximum_adhesion_distance(
		parameters.doubles("base_cell_adhesion_distance"));

	// Now, let's define another cell type. 
	// It's best to just copy the default and modify it. 
	
	motile_cell = cell_defaults; 
	motile_cell.type = 1; 
	motile_cell.name = "motile tumor cell"; 
	
	// make sure the new cell type has its own reference phenotype
	
	motile_cell.parameters.pReference_live_phenotype = &( motile_cell.phenotype ); 
	
	// enable random motility 
	motile_cell.phenotype.motility.is_motile = true; 
	motile_cell.phenotype.motility.persistence_time = parameters.doubles( "motile_cell_persistence_time" ); // 15.0; 
	motile_cell.phenotype.motility.migration_speed = parameters.doubles( "motile_cell_migration_speed" );// edited
	motile_cell.phenotype.motility.migration_bias = parameters.doubles( "motile_cell_migration_bias" );// edited
	
	// Set cell-cell adhesion to 5% of other cells 
	motile_cell.phenotype.mechanics.cell_cell_adhesion_strength *= parameters.doubles( "motile_cell_relative_adhesion" ); // 0.05; 
	
	// Set apoptosis to zero 
	motile_cell.phenotype.death.rates[apoptosis_model_index] = parameters.doubles( "motile_cell_apoptosis_rate" ); // 0.0; 
	
	// Set proliferation to 10% of other cells. 
	// Alter the transition rate from G0G1 state to S state
	motile_cell.phenotype.cycle.data.transition_rate(G0G1_index,S_index) *= 
		parameters.doubles( "motile_cell_relative_cycle_entry_rate" ); // 0.1; 

	//***WEIHONG EDITED*** Copied and adapted from 'biorobots,cpp' lines 207
	if (proliferation) {
		motile_cell.functions.update_phenotype = motile_cell_increase_proliferation;
	}
	if (differentiation) {
		r1 = UniformRandom();
		//if (r1 > 0.5) {
			motile_cell.functions.update_phenotype = motile_cell_differentiation;
		//}
	}

	// made up a new cell type called bob
	bob_cell = cell_defaults;
	bob_cell.type = 2;
	bob_cell.name = "bob cell";

	// make sure the new cell type has its own reference phenotype

	bob_cell.parameters.pReference_live_phenotype = &(bob_cell.phenotype);

	// set motility to zero
	bob_cell.phenotype.motility.is_motile = false;
	bob_cell.phenotype.motility.persistence_time = parameters.doubles("bob_cell_persistence_time");
	bob_cell.phenotype.motility.migration_speed = parameters.doubles("bob_cell_migration_speed");
	bob_cell.phenotype.motility.migration_bias = 0.0;// completely random 

	// Set cell-cell adhesion to 5% of other cells 
	bob_cell.phenotype.mechanics.cell_cell_adhesion_strength *= parameters.doubles("bob_cell_relative_adhesion");

	// Set apoptosis to zero 
	bob_cell.phenotype.death.rates[apoptosis_model_index] = parameters.doubles("bob_cell_apoptosis_rate"); 

	// Add rule for secretion of chemoattractant
	if (secretion) {
		int glucose_index = microenvironment.find_density_index("glucose");
		//bob_cell.functions.update_phenotype = bob_cell_secretion;
		bob_cell.phenotype.secretion.uptake_rates[glucose_index] = 0;
		bob_cell.phenotype.secretion.secretion_rates[glucose_index] = 10;
		bob_cell.phenotype.secretion.saturation_densities[glucose_index] = 1000;
	}

	// Alter the transition rate from G0G1 state to S state
	bob_cell.phenotype.cycle.data.transition_rate(G0G1_index, S_index) *=
		parameters.doubles("bob_cell_relative_cycle_entry_rate");


	// made up a new cell type called TA (transit amplifying)
	TA_cell = cell_defaults;
	TA_cell.type = 3;
	TA_cell.name = "TA cell";

	// make sure the new cell type has its own reference phenotype
	TA_cell.parameters.pReference_live_phenotype = &(TA_cell.phenotype);

	// enable random motility 
	TA_cell.phenotype.motility.is_motile = true;
	TA_cell.phenotype.motility.persistence_time = parameters.doubles("TA_cell_persistence_time");
	TA_cell.phenotype.motility.migration_speed = parameters.doubles("TA_cell_migration_speed");
	TA_cell.phenotype.motility.migration_bias = 0.0;// completely random 

	// Set cell-cell adhesion to 5% of other cells 
	TA_cell.phenotype.mechanics.cell_cell_adhesion_strength *= parameters.doubles("TA_cell_relative_adhesion");

	// Set apoptosis to zero 
	TA_cell.phenotype.death.rates[apoptosis_model_index] = parameters.doubles("TA_cell_apoptosis_rate");

	// Set proliferation to 10% of other cells. 
	// Alter the transition rate from G0G1 state to S state
	TA_cell.phenotype.cycle.data.transition_rate(G0G1_index, S_index) *=
		parameters.doubles("TA_cell_relative_cycle_entry_rate");

	if (chemotaxis) {
		TA_cell.functions.update_migration_bias = chemotaxis_bias_function;
	}

	fred_cell = cell_defaults;
	fred_cell.type = 4;
	fred_cell.name = "fred cell";

	// make sure the new cell type has its own reference phenotype
	fred_cell.parameters.pReference_live_phenotype = &(fred_cell.phenotype);

	// enable random motility 
	fred_cell.phenotype.motility.is_motile = false;
	fred_cell.phenotype.motility.persistence_time = parameters.doubles("fred_cell_persistence_time");
	fred_cell.phenotype.motility.migration_speed = parameters.doubles("fred_cell_migration_speed");
	fred_cell.phenotype.motility.migration_bias = 0.0;// completely random 

	// Set cell-cell adhesion to 5% of other cells 
	fred_cell.phenotype.mechanics.cell_cell_adhesion_strength *= parameters.doubles("fred_cell_relative_adhesion");

	// Set apoptosis to zero 
	fred_cell.phenotype.death.rates[apoptosis_model_index] = parameters.doubles("fred_cell_apoptosis_rate");

	// Set proliferation to 10% of other cells. 
	// Alter the transition rate from G0G1 state to S state
	fred_cell.phenotype.cycle.data.transition_rate(G0G1_index, S_index) *=
		parameters.doubles("fred_cell_relative_cycle_entry_rate");

	build_cell_definitions_maps();
	display_cell_definitions(std::cout);
	//***WEIHONG EDITED FINISH***

	return; 
}

void setup_microenvironment(void)
{
	// set domain parameters 

/* now this is in XML
	default_microenvironment_options.X_range = {-1000, 1000};
	default_microenvironment_options.Y_range = {-1000, 1000};
	default_microenvironment_options.simulate_2D = true;
*/

// make sure to override and go back to 2D 
	if (default_microenvironment_options.simulate_2D == false)
	{
		std::cout << "Warning: overriding XML config option and setting to 2D!" << std::endl;
		default_microenvironment_options.simulate_2D = true;
	}

	/* now this is in XML
		// no gradients need for this example

		default_microenvironment_options.calculate_gradients = false;

		// set Dirichlet conditions

		default_microenvironment_options.outer_Dirichlet_conditions = true;

		// if there are more substrates, resize accordingly
		std::vector<double> bc_vector( 1 , 38.0 ); // 5% o2
		default_microenvironment_options.Dirichlet_condition_vector = bc_vector;

		// set initial conditions
		default_microenvironment_options.initial_condition_vector = { 38.0 };
	*/

	// put any custom code to set non-homogeneous initial conditions or 
	// extra Dirichlet nodes here.

	// initialize BioFVM 

	initialize_microenvironment();

	//***WEIHONG EDITED***
	if (dirichlet_center) {
		// set glucose to 20 at the centre with Dirichlet conditions
		get_default_microenvironment()->update_dirichlet_node(1226, 1, 100);
		// keep oxygen constant at the centre so that cells don't die
		get_default_microenvironment()->update_dirichlet_node(1226, 0, 38);
	}
	//***WEIHONG EDITED FINISH***
	
	return; 
}

void setup_tissue( void )
{
	// initialising cell
	Cell* pC;

	//***WEIHONG EDITED***

	//SECRETION TEST
	if (secretion_test) {
		for (int i = 0; i < 100; i++) {		// Bob cells in a spiral towards the centre
			pC = create_cell(bob_cell);
			pC->assign_position(4.5 * i * cos(M_PI * i / 100), 4.5 * i * sin(M_PI * i / 100), 0.0);
			pC->set_radius(5.0);
			pC->is_movable = false;	// Set bob cells fixed in place
		}
		for (int i = 0; i < 100; i++) {		// Plot 100 random motile cells
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(1000 * r1 - 500, 1000 * r2 - 500, 0.0);
		}
	}

	//SECRETION TEST 2
	if (secretion_test2) {
		for (int i = 0; i <= 50; i++) {	// Bob cells on vertical line in the middle
			pC = create_cell(fred_cell);
			pC->assign_position(0.0, 500 - i * 20, 0.0);
			//pC->is_movable = false;	// Set bob cells fixed in place
		}
		for (int i = 0; i <= 100; i++) {	// Random motile cells over the whole area
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(1000 * r1 - 500, 1000 * r2 - 500, 0.0);
		}
	}

	//SECRETION TEST 3
	if (secretion_test3) {
		for (int i = 0; i <= 10; i++) {		// Random bob cells in the middle
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(bob_cell);
			pC->assign_position(50 * r1 - 25, 50 * r2 - 25, 0.0);
		}
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Plot motile cells in a circle
			pC = create_cell(motile_cell);
			pC->assign_position(400 * cos(theta), 400 * sin(theta), 0.0);
			theta += (M_PI / 50);
		}
	}

	//DIFFERENTIATION TEST
	if (differentiation_test) {
		for (int i = 0; i < 50; i++) {	// Plot 50 random motile cells
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(200 * r1 - 100, 200 * r2 - 100, 0.0);
		}
		for (int i = 0; i < 3; i++) {	// Plot 3 random bob cells
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(bob_cell);
			pC->assign_position(100 * r1 - 50, 100 * r2 - 50, 0.0);
		}
	}

	// CHEMOTAXIS TOWARDS THE CENTRE
	if (chemotaxis_center) {
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Plot motile cells in a circle
			pC = create_cell(motile_cell);
			pC->assign_position(400 * cos(theta), 400 * sin(theta), 0.0);
			theta += (M_PI / 50);
		}
	}

	// NULL MODEL: PLOTTING RANDOM CELLS IN THE MIDDLE OF CIRCLE
	if (null_model) {
		for (int i = 0; i <= 20; i++) {
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(100 * r1 - 50, 100 * r2 - 50, 0.0);
		}
	}

	// SPIRAL FORMATION TO IMITATE MIGRATION TOWARDS CENTRE OF THE EYE
	if (spiral) {
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Plot motile cells in a circle
			pC = create_cell(motile_cell);
			pC->assign_position(400 * cos(theta), 400 * sin(theta), 0.0);
			//pC->set_target_radius(5.0);
			theta += (M_PI / 50);
		}
		for (int i = 0; i < 100; i++) {		// Bob cells in a spiral towards the centre
			pC = create_cell(bob_cell);
			pC->assign_position(4.5 * i * cos(M_PI * i / 100), 4.5 * i * sin(M_PI * i / 100), 0.0);
			pC->set_radius(3.0);
			pC->is_movable = false;
		}
	}

	if (spiral2) {
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Bob cells in a spiral towards the centre
			pC = create_cell(bob_cell);
			pC->assign_position(4.5 * i * cos(M_PI * i / 100), 4.5 * i * sin(M_PI * i / 100), 0.0);
			pC->set_radius(5.0);
			pC->is_movable = false;
		}
		for (int i = 0; i <= 50; i++) {
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(50 * r1 - 450, 500 * r2 - 250, 0.0);
		}
	}

	if (spiral3) {
		int r = 100; // outer radius
		int a = 0; // inner radius
		int b = 5; // increment per rev
		int n = 20;
		double th = 40 * M_PI; // angle
		for (int i = 0; i<=159; i++) {
			double x = (450 * i / 159) * cos(i * th / 159);
			double y = (450 * i / 159) * sin(i * th / 159);
			pC = create_cell(bob_cell);
			pC->assign_position(x, y, 0.0);
			pC->set_target_radius(5.0);
			pC->is_movable = false;
		}
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Plot motile cells in a circle
			pC = create_cell(motile_cell);
			pC->assign_position(400 * cos(theta), 400 * sin(theta), 0.0);
			theta += (M_PI / 50);
		}
	}

	if (spiral4) {
		// Plot bob cells
		int r = 100; // outer radius
		int a = 0; // inner radius
		int b = 5; // increment per rev
		int n = 20; // number of turns
		double th = 40 * M_PI; // angle
		for (int i = 0; i <= 159; i++) {
			double x = (450 * i / 159) * cos(i * th / 159);
			double y = (450 * i / 159) * sin(i * th / 159);
			pC = create_cell(bob_cell);
			pC->assign_position(x, y, 0.0);
			pC->set_target_radius(5.0);
			pC->is_movable = false;
		}
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Plot motile cells in a circle
			pC = create_cell(motile_cell);
			pC->assign_position(450 * cos(theta), 450 * sin(theta), 0.0);
			theta += (M_PI / 50);
		}
		theta = 0;
		for (int i = 0; i < 20; i++) {		// Plot fred cells in a circle randomly placed
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(fred_cell);
			pC->assign_position(450 * cos(theta) - (50 * (r1 - 0.5)) , 450 * sin(theta) - (50 * (r2 - 0.5)) , 0.0);
			theta += (M_PI / 10);
		}
	}

	// GRID FORMATION TO IMITATE TYPOGRAPHY/MICROPATTERNING
	if (grid) {
		for (int i = 0; i <= 5; i++) {	// Bob cells in a grid
			for (int j = 0; j <= 25; j++) {
				pC = create_cell(bob_cell);
				pC->assign_position(200 * i - 500, 40 * j - 500, 0.0);
				pC = create_cell(bob_cell);
				pC->assign_position(40 * j - 500, 200 * i - 500, 0.0);
			}
		}
		if (false) {	// Plot motile cells in a circle
			double theta = 0;
			for (int i = 0; i < 24; i++) {
				pC = create_cell(motile_cell);
				pC->assign_position(200 * cos(theta), 200 * sin(theta), 0.0);
				theta += (M_PI / 12);
			}
		}
		if (true) {		// Plot motile cells in random formation: Adapted from Frankie's code
			for (int i = 0; i <= 100; i++) {
				r1 = UniformRandom();
				r2 = UniformRandom();
				pC = create_cell(motile_cell);
				pC->assign_position(500 * r1 - 250, 500 * r2 - 250, 0.0);
			}
		}
	}

	// TEST FOR ADHESION BETWEEN BOB CELLS AND MOTILE CELLS
	if (adhesion) {
		pC = create_cell(motile_cell);	// One motile cell
		pC->assign_position(0.0, 0.0, 0.0);
		pC = create_cell(bob_cell);		// One bob cell
		pC->assign_position(0.0, 0.0, 0.0);
	}

	// TEST FOR 'motile_cell_increase_proliferation' FUNCTION
	if (proliferation_test) {
		for (int i = 0; i <= 200; i++) {	// Random bob cells on the right side
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(bob_cell);
			pC->assign_position(500 * r1, 1000 * r2 - 500, 0.0);
			//pC->set_total_volume(20.0);
		}
		for (int i = 0; i <= 100; i++) {	// Random motile cells over the whole area
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(1000 * r1 - 500, 1000 * r2 - 500, 0.0);
		}
	}

	if (topography) {
		for (int i = 0; i <= 20; i++) {
			r1 = UniformRandom();
			r2 = UniformRandom();
			pC = create_cell(motile_cell);
			pC->assign_position(100 * r1 - 50, 100 * r2 - 50, 0.0);
		}
		double theta = 0;
		for (int i = 0; i < 100; i++) {		// Plot motile cells in a circle
			pC = create_cell(bob_cell);
			pC->assign_position(110 * cos(theta), 110 * sin(theta), 0.0);
			pC->set_target_radius(5.0);
			pC->is_movable = false;
			theta += (M_PI / 50);
		}
	}
	//***WEIHONG EDITED FINISHED***

	return; 
}

std::vector<std::string> my_coloring_function( Cell* pCell )
{
	// start with flow cytometry coloring 
	
	//std::vector<std::string> output = false_cell_coloring_cytometry(pCell); 
	//	
	//if( pCell->phenotype.death.dead == false && pCell->type == 1 )
	//{
	//	 output[0] = "black"; 
	//	 output[2] = "black"; 
	//}
	//
	//return output; 

	std::vector<std::string> output = false_cell_coloring_cytometry(pCell);
	static std::string motile_color = parameters.strings("motile_color");  // tutorial 
	static std::string bob_color = parameters.strings("bob_color"); // added bob cell colour
	static std::string TA_color = parameters.strings("TA_color"); // added TA cell colour
	static std::string fred_color = parameters.strings("fred_color"); // added fred cell colour

	if (pCell->phenotype.death.dead == false && pCell->type == 1)
	{
		output[0] = motile_color;
		output[2] = motile_color;
	}

	//***WEIHONG EDITED***
	if (pCell->phenotype.death.dead == false && pCell->type == 2)
	{
		output[0] = bob_color;
		output[2] = bob_color;
	}
	if (pCell->phenotype.death.dead == false && pCell->type == 3)
	{
		output[0] = TA_color;
		output[2] = TA_color;
	}
	if (pCell->phenotype.death.dead == false && pCell->type == 4)
	{
		output[0] = fred_color;
		output[2] = fred_color;
	}
	//***WEIHONG EDITED FINISHED***

	return output;
}

//***WEIHONG EDITED*** Copied and edited from PhysiCell User Guide
void chemotaxis_bias_function(Cell* pCell, Phenotype& phenotype, double dt)
{
	// quickly find glucose
	static int glucose_index = microenvironment.find_density_index("glucose");
	// sample glucose
	double glucose = pCell->nearest_density_vector()[glucose_index];
	// set direction along glucose gradients
	phenotype.motility.migration_bias_direction = pCell->nearest_gradient(glucose_index);
	normalize(&(phenotype.motility.migration_bias_direction));
	// set speed proportional to glucose, scaled by chosen glucose value ( 350 );
	// with a maximum of 0.3 micron per minute
	double theta = glucose / 350.0;
	phenotype.motility.migration_speed = 0.3 * (1.0 - theta);
	if (phenotype.motility.migration_speed > 0.3)
	{
		phenotype.motility.migration_speed = 0.3;
	}
	// the greater the glucose, the more biased the motion
	phenotype.motility.migration_bias = theta;
	return;
}

void motile_cell_increase_proliferation(Cell* pCell, Phenotype& phenotype, double dt)
{
	int G0G1_index = flow_cytometry_separated_cycle_model.find_phase_index(PhysiCell_constants::G0G1_phase);
	int S_index = flow_cytometry_separated_cycle_model.find_phase_index(PhysiCell_constants::S_phase);
	int num_cells = pCell->cells_in_my_container().size();
	for (int i = 0; i < num_cells; i++) { // loop through all the neighbors of the motile cell
		if (pCell->cells_in_my_container()[i]->type == 4) { // find out if the neighbor is a fred cell
			pCell->phenotype.cycle.data.transition_rate(G0G1_index, S_index) = parameters.doubles("motile_cell_crystallin_proliferation_rate");
			break;	// stop searching for fred cell neighbours because motile cell is already increased prolif rate
		}
		else {
			pCell->phenotype.cycle.data.transition_rate(G0G1_index, S_index) = parameters.doubles("motile_cell_relative_cycle_entry_rate");
		}
	}
	return;
}

void motile_cell_differentiation(Cell* pCell, Phenotype& phenotype, double dt)
{
	int G0G1_index = flow_cytometry_separated_cycle_model.find_phase_index(PhysiCell_constants::G0G1_phase);
	int S_index = flow_cytometry_separated_cycle_model.find_phase_index(PhysiCell_constants::S_phase);
	int num_cells = pCell->cells_in_my_container().size();
	for (int i = 0; i < num_cells; i++) { // loop through all the neighbors of the motile cell
		if (pCell->cells_in_my_container()[i]->type == 4) { // find out if the neighbor is a fred cell
			// get position of motile cell
			std::vector<double> cell_position(3);
			cell_position = pCell->position;
			// create TA cell in the same position as the motile cell
			Cell* pC = create_cell(TA_cell);
			pC->assign_position(cell_position);
			break;	// stop searching for fred cell neighbours because motile cell is already removed
		}
	}
	return;
}

void bob_cell_secretion(Cell* pCell, Phenotype& phenotype, double dt)
{
	int glucose_index = microenvironment.find_density_index("glucose");
	phenotype.secretion.secretion_rates[glucose_index] = 142;
	return;
}
//***WEIHONG EDITED FINISH***