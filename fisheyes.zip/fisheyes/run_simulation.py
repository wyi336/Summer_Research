import os

#Run Physicell project simulation
os.system("make data-cleanup")
os.system("make reset")
os.system("make template2D")
os.system("make")
os.system("project2D")