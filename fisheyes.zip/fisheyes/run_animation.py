from pyMCDS import pyMCDS
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import os

#This script outputs an mp4 file visualising cell simulation output from XML files
#Author: Frankie Patten-Elliott (adapted from Stack Overflow https://stackoverflow.com/questions/9401658/how-to-animate-a-scatter-plot)

frames_no = 241  #set the number of time frames desired to be animated
Writer = animation.writers['ffmpeg']  #Ensure animation writer ffmpeg file present in directory
writer = Writer(fps=5, metadata=dict(artist='Me'), bitrate=1800)

# Weihong edited
os.chdir('output')

#An animated scatter plot using matplotlib.animations.FuncAnimation
class AnimatedScatter(object):   
    def __init__(self):
        #Setup the figure and axes
        self.fig, self.ax = plt.subplots()
        self.ax.set_aspect('equal')
        circle1 = plt.Circle((0, 0), 500, color='k', fill=False)
        self.ax.add_artist(circle1)
        #Setup FuncAnimation
        self.ani = animation.FuncAnimation(self.fig, self.update, frames = frames_no, 
                                          init_func=self.setup_plot, blit=True)
        self.ani.save('Simulation_Output.mp4', writer=writer)
    
    #Initial drawing of the scatter plot
    def setup_plot(self):
        x = np.array(self.data(0)[0][:,0])
        y = np.array(self.data(0)[0][:,1])
        s = np.array(self.data(0)[2])
        c = np.array(self.data(0)[1])
        self.scat = self.ax.scatter(x, y, s, c, vmin=0, vmax=1,
                                    cmap="jet", edgecolor="k")
        self.ax.axis([-500, 500, -500, 500])  #set animation domain
        return self.scat,

    #Generate positions of cells from output .xml files
    def data(self, i):   
        if i<10:
            mcds = pyMCDS('output0000000'+ str(i) +'.xml', )
        elif i<100:
            mcds = pyMCDS('output000000'+ str(i) +'.xml', )
        elif i<1000:
            mcds = pyMCDS('output00000'+ str(i) +'.xml', )
        
        # get our cells data and figure out which cells are in the plane
        cell_df = mcds.get_cell_df()
        ds = mcds.get_mesh_spacing()
        inside_plane = (cell_df['position_z'] < ds) & (cell_df['position_z'] > -ds)
        plane_cells = cell_df[inside_plane]
        
        # get our cells of interest
        alive_cells = plane_cells[plane_cells['cycle_model'] < 6]
        dead_cells = plane_cells[plane_cells['cycle_model'] > 6]
        xy = np.zeros((len(plane_cells), 2))
        size = np.zeros((len(plane_cells), 1))
        colours = ["" for x in range(len(plane_cells))]
        xy[:,0] = plane_cells['position_x'].values.T
        xy[:,1] = plane_cells['position_y'].values.T
        #Only show cells that are in the domain and alive
        for j in range(len(plane_cells)):
            #***Weihong***Commented this line of code below because the cells were in a different frame to the circle
            #if plane_cells['position_x'][j] + plane_cells['position_y'][j] - 0.001*(plane_cells['position_x'][j])**2 - 0.001*(plane_cells['position_y'][j])**2 > 250:
            if plane_cells['position_x'][j]**2 + plane_cells['position_y'][j]**2 < 495**2:
                if plane_cells['cell_type'][j] == 1:    # cell type is motile cell
                    size[j] = plane_cells['total_volume'][j]/100
                    colours[j] = 'b'
                    ###***Weihong edited***
                    # Colouring according to phase (blue for growth, green for division) - we won't do this for now
                    # if plane_cells['current_phase'][j] == 4:
                    #     size[j] = 20
                    #     colours[j] = 'b'
                    # elif plane_cells['current_phase'][j] == 10:
                    #     size[j] = 20
                    #     colours[j] = 'g'
                    # elif plane_cells['current_phase'][j] == 12:
                    #     size[j] = 20
                    #     colours[j] = 'g'
                    # elif plane_cells['current_phase'][j] == 13:
                    #     size[j] = 20
                    #     colours[j] = 'g'
                    # elif plane_cells['current_phase'][j] == 102:
                    #     size[j] = 20
                    #     colours[j] = 'k'
                    # elif plane_cells['current_phase'][j] == 101:
                    #     size[j] = 20
                    #     colours[j] = 'k'
                    # else:
                    #     size[j] = 20
                    #     colours[j] = 'r'
                    if plane_cells['current_phase'][j] > 99:
                        size[j] = plane_cells['total_volume'][j]/100
                        colours[j] = 'k'
                elif plane_cells['cell_type'][j] == 2:  # cell type is bob cell
                    size[j] = plane_cells['total_volume'][j]/100
                    colours[j] = 'm'
                    if plane_cells['current_phase'][j] > 99:
                        size[j] = plane_cells['total_volume'][j]/100
                        colours[j] = 'k'
                elif plane_cells['cell_type'][j] == 3:  # cell type is TA cell
                    size[j] = plane_cells['total_volume'][j]/100
                    colours[j] = 'y'
                    if plane_cells['current_phase'][j] > 99:
                        size[j] = plane_cells['total_volume'][j]/100
                        colours[j] = 'k'
                elif plane_cells['cell_type'][j] == 4:  # cell type is fred cell
                    size[j] = plane_cells['total_volume'][j]/100
                    colours[j] = 'g'
                    if plane_cells['current_phase'][j] > 99:
                        size[j] = plane_cells['total_volume'][j]/100
                        colours[j] = 'k'
            else:
                size[j] = 0
                colours[j] = '#111111'
        ###***Weihong edited end***
        return xy, colours, size
    
    #Update the scatter plot
    def update(self, i):
        #Set x and y data
        xy = np.array(self.data(i)[0])
        self.scat.set_offsets(xy)
        #Set sizes
        s = np.array(self.data(i)[2])
        self.scat.set_sizes(s[:,0])
        #Set colours
        colours = np.array(self.data(i)[1])
        self.scat.set_color(colours)
        #set edgecolors
        self.scat.set_edgecolor('k')
        
        return self.scat,

if __name__ == '__main__':
    a = AnimatedScatter()
    #plt.show()